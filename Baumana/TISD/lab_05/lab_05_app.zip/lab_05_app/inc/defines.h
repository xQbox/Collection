#ifndef _DEFINES_H_

#define OVERFLOW_ERROR 1
#define ALLOC_ERROR 2

#define MAXLEN 1024

#define EPS 1e-8

#define _DEFINES_H_
#endif