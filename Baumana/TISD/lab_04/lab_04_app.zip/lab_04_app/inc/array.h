#ifndef ARRAY_H_
#define ARRAY_H_

#include "libmy.h"

int add_a(int *array, size_t *k);

void delete_a(int *array, size_t *k);

#endif // ARRAY_H_