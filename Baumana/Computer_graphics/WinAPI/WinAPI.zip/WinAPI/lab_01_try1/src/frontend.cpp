#include <libmy.h>


   // CreateWindow("BUTTON", "Button 1", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            // 600, 50, 100, 30, hWnd, NULL, NULL, NULL);
            // CreateWindow("BUTTON", "Button 2", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            // 600, 100, 100, 30, hWnd, NULL, NULL, NULL);

bool InitWorkArea(void)
{
    CreateWindow()
}