#ifndef _LIBMY_H_
#define _LIBMY_H_

// standart libs
#include <windows.h>
#include <stdio.h>

// My libs
#include <frontend.h>
#include <menudemo.h>


#endif // _LIBMY_H_