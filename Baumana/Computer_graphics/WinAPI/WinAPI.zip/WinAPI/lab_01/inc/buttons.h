#ifndef BUTTONS_H_
#define BUTTONS_H_


#define IDC_BUTTONSMALLER   101
#define IDC_BUTTONBIGGER    102


#define IDC_BUTTONPOINT     110
#define IDC_BUTTONCONNECT   111


#define IDC_BUTTONPIXEL     120
#define IDC_BUTTONSEGMENT   121
#define IDC_BUTTONSQUARE    122
#define IDC_BUTTONRECTANGLE 123



#define IDC_BUTTONSOLVE     130
#define IDC_BUTTONAPPLY     131
    
#endif // BUTTONS_H_