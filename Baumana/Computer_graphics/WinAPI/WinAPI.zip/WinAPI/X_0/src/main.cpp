// #include <iostream>
#include "menudemo.h"
#include <stdio.h>
#include <Windows.h>

#define DIV     5 
// #pragma comment(lib, "user32.lib")
// #pragma comment(lib, "gdi32.lib")

HMENU MyMenu(HWND hWnd)
{
    HMENU  hMenu = CreateMenu();


    HMENU hMenuPopup = CreateMenu();

    AppendMenuW(hMenuPopup, MF_POPUP, IDM_CREATE, L"Создать");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_OPEN, L"Открыть");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_SAVE, L"Сохранить");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_SAVEAS, L"Сохранить как...");
    AppendMenuW(hMenuPopup, MF_SEPARATOR, 0, NULL);
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_RECENT, L"Последние");
    AppendMenuW(hMenuPopup, MF_SEPARATOR, 0, NULL);
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_EXIT, L"Выход");

    AppendMenuW(hMenu, MF_POPUP, (UINT) hMenuPopup, L"Файл");


    hMenuPopup = CreateMenu();

    AppendMenuW(hMenuPopup, MF_POPUP, IDM_UNDO, L"Отменить");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_DELETE, L"Удалить");
    AppendMenuW(hMenuPopup, MF_SEPARATOR, 0, NULL);
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_CUT, L"Вырезать");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_COPY, L"Скопировать");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_PASTE, L"Вставить");

    AppendMenuW(hMenu, MF_POPUP, (UINT) hMenuPopup, L"Изменить");
    

    hMenuPopup = CreateMenu();

    AppendMenuW(hMenuPopup, MF_POPUP, IDM_AUTHOR, L"Об авторе");
    AppendMenuW(hMenuPopup, MF_POPUP, IDM_TASK, L"О задаче");

    AppendMenuW(hMenu, MF_POPUP, (UINT) hMenuPopup, L"О программе");


    AppendMenuW(hMenu, MF_POPUP, IDM_INFO, L"Справка");


    SetMenu(hWnd, hMenu);
    return hMenu;
}

// user interactions
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{

    static BOOL fState[DIV][DIV];
    static int cxBlock, cyBlock;
    HDC hdc, hdc1;
    PAINTSTRUCT ps;
    RECT rect;
    // RECT clientRect;
    int x, y; 
    static HMENU hMenu;
    
    static bool bFlag = true;

    if (iMessage == WM_CREATE)
    {
        hMenu = MyMenu(hWnd);
        return 0;
    }
    if (iMessage == WM_SIZE)
    {
        cxBlock = LOWORD(lParam) / DIV;
        cyBlock = HIWORD(lParam) / DIV;
        return 0;  
    }
    if (iMessage == WM_LBUTTONDOWN)
    {
        x = LOWORD(lParam) / cxBlock;
        y = HIWORD(lParam) / cyBlock;

/* 
Take information from left and top of the window and transform coordinates 
with application and menu affect (calculate only WORKING USER AREA)  
*/
        // RECT rect1;
        // GetClientRect(hWnd, &rect1);
        // MapWindowPoints(hWnd, GetParent(hWnd), (LPPOINT) &rect1, 2);
        // // POINT wp;
        // // GetCurrentPositionEx(hdc1, &wp);

        // printf("CURRENT MAIN WINDOWS TOP : %ld\n", rect1.top);
        // printf("CURRENT MAIN WINDOWS LEFT : %ld\n", rect1.left);
        // printf("CURRENT MAIN WINDOWS BOTTOM : %ld\n", rect1.bottom);
        // printf("CURRENT MAIN WINDOWS RIGHT : %ld\n", rect1.right);


/* 
Take information from left and top of the window 
transform coordinates without menu and application title line  
*/

// the child window hWnd
// and the parent window hWnd
        // RECT rectCW;
        // GetWindowRect(hWnd, &rectCW); 
// child window rect in screen coordinates
        // POINT ptCWPos = { rectCW.left, rectCW.top };
        // ScreenToClient(HWND_DESKTOP, &ptCWPos); 
// transforming the child window pos
// from screen space to parent window space
        // LONG iWidth, iHeight;
        // iWidth = rectCW.right - rectCW.left;
        // iHeight = rectCW.bottom - rectCW.top;

        // rectCW.left = ptCWPos.x;
        // rectCW.top = ptCWPos.y;
        // rectCW.right = rectCW.left + iWidth;
        // rectCW.bottom = rectCW.right + iHeight; // child window rect in parent window space


        // printf("CURRENT MAIN WINDOWS TOP : %ld\n", rectCW.top);
        // printf("CURRENT MAIN WINDOWS LEFT : %ld\n", rectCW.left);
        // printf("CURRENT MAIN WINDOWS BOTTOM : %ld\n", rectCW.bottom);
        // printf("CURRENT MAIN WINDOWS RIGHT : %ld\n", rectCW.right);

        // SetCursorPos(100, 100);
        // if (bFlag)
        // {
        //     SetCursorPos((abs(rect1.left - rect1.top)) / 2, (abs(rect1.right - rect1.bottom)) / 2);
        //     bFlag = false;
        // }
        // else
        // {
        //     SetCursorPos((abs(rectCW.left - rect1.top)) / 2, (abs(rectCW.right - rect1.bottom)) / 2);
        //     bFlag = true;
        // }
       
       
        // POINT point;
        // ScreenToClient(hWnd, &point);
       
        // printf("STRANGE x : %ld\n", point.x);
        // printf("STRANGE y : %ld\n", point.y);
        
        // ClientToScreen(hWnd, &point);
       
        // printf("STRANGE x : %ld\n", point.x);
        // printf("STRANGE y : %ld\n", point.y);
        
/*Set the position of cursor at the middle of the client screen area*/        
        
        RECT tmp;
        POINT point;

        GetClientRect(hWnd, &tmp);
        
        
        point.x = tmp.left + ((tmp.right - tmp.left) / 2);
        point.y = tmp.top + ((tmp.bottom - tmp.top) / 2);
        
        ClientToScreen(hWnd, &point);
        SetCursorPos(point.x, point.y);

        
        if (x < DIV && y < DIV)
        {
//  ^= - XOR 
            fState [x][y] ^= 1;
            rect.left = x * cxBlock;
            rect.top = y * cyBlock;
            rect.right = (x + 1) * cxBlock;
            rect.bottom = (y + 1) * cyBlock;
            InvalidateRect(hWnd, &rect, FALSE);
        }
        else
        {
            MessageBeep(0);
        }
        return 0; 
    }
    if (iMessage == WM_PAINT)
    { 
        hdc = BeginPaint(hWnd, &ps);

        for (x = 0; x < DIV; x++)
        {
            for (y = 0; y < DIV; y++)
            {
                Rectangle(hdc, x * cxBlock, y * cyBlock,
                (x + 1) * cxBlock, (y + 1) * cyBlock);

                if(fState [x][y])
                {
                    MoveToEx(hdc, x * cxBlock, y * cyBlock, NULL);
                    LineTo(hdc,(x + 1) * cxBlock,(y + 1) * cyBlock);
                    MoveToEx(hdc, x * cxBlock,(y + 1) * cyBlock, NULL);
                    LineTo(hdc,(x + 1) * cxBlock, y * cyBlock);
                }
            }
        }
        EndPaint(hWnd, &ps);
        return 0; 
    }
    if (iMessage == WM_DESTROY)
    {
        DestroyMenu(hMenu);
        PostQuitMessage(0);
        return 0;
    } 
    return DefWindowProc(hWnd, iMessage, wParam, lParam);
}

// LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
// {
//     static HWND hwndChild[DIV][DIV];
//     int cxBlock, cyBlock, x, y;
//     switch(iMsg)
//     {
//         case WM_CREATE :
//             for(x = 0; x < DIV; x++)
//             {
//                 for(y = 0; y < DIV; y++)
//                 {
//                     hwndChild[x][y] = CreateWindow("childWindow", NULL,
//                     WS_CHILDWINDOW | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(y << 8 | x),
//                     (HINSTANCE) GetWindowLong(hwnd, GWL_HINSTANCE), NULL);
//                 }
//             }
//             return 0;
        
//         case WM_SIZE :
//             cxBlock = LOWORD(lParam) / DIV;
//             cyBlock = HIWORD(lParam) / DIV;
//             for(x = 0; x < DIV; x++)
//             {    
//                 for(y = 0; y < DIV; y++)
//                 {
//                     MoveWindow(hwndChild[x][y], x * cxBlock, y * cyBlock, cxBlock, cyBlock, TRUE);
//                 }
//             }
//             return 0;
        
//         case WM_LBUTTONDOWN :
//             MessageBeep(0);
//             return 0;
//         case WM_DESTROY :
//             PostQuitMessage(0);
//             return 0;
//     }
//     return DefWindowProc(hwnd, iMsg, wParam, lParam);
// }


// LRESULT CALLBACK ChildWndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
// {
//     HDC hdc;
//     PAINTSTRUCT ps;
//     RECT rect;
//     switch(iMsg)
//     {
//         case WM_CREATE :
//             SetWindowWord(hwnd, 0, 0); // on/off flag
//             return 0;
//         case WM_LBUTTONDOWN :
//             SetWindowWord(hwnd, 0, 1 ^ GetWindowWord(hwnd, 0));
//             InvalidateRect(hwnd, NULL, FALSE);
//             return 0;
        
//         case WM_PAINT :
//             hdc = BeginPaint(hwnd, &ps);
//             GetClientRect(hwnd, &rect);
//             Rectangle(hdc, 0, 0, rect.right, rect.bottom);
//             if(GetWindowWord(hwnd, 0))
//             {
//                 MoveToEx(hdc, 0, 0, NULL);
//                 LineTo(hdc, rect.right, rect.bottom);
//                 MoveToEx(hdc, 0, rect.bottom, NULL);
//                 LineTo(hdc, rect.right, 0);
//             }
//             EndPaint(hwnd, &ps);
//             return 0;
//     }
//     return DefWindowProc(hwnd, iMsg, wParam, lParam);
// }

// int  WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) 
int main(int argc, char **argv)
{
// При нуле возвращает дескриптор текущего приложения
// библиотеки , если она была загружена до этого 
// Получение дескриптора ранее загруженной библиотеки (имя дин. библиотеки в виде строки)
    HINSTANCE hInstance = GetModuleHandle(0); 
    WNDCLASSEX wnd_class;
    const char *szWndClassName= "my window";

    memset(&wnd_class, 0, sizeof(wnd_class));
    

    wnd_class.cbSize = sizeof(wnd_class);
    wnd_class.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    wnd_class.lpfnWndProc = WndProc;
    wnd_class.hInstance = hInstance;
    wnd_class.lpszClassName = szWndClassName;
    wnd_class.hCursor = LoadCursor(NULL, IDC_ARROW);
    wnd_class.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wnd_class.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

// CS_DBLCLKS give an option to recieve doubleclick message from mouse
    wnd_class.style =  CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    

    // const char *szMenuName = "MenuDemo";
    // wnd_class.lpszMenuName = "MenuDemo";

    RegisterClassEx(&wnd_class); // register class for application
    
    const char *szTitle = "Paint"; 

    // const char *szChildClass = "childWindow";
    // wnd_class.lpfnWndProc = ChildWndProc;
    // wnd_class.cbWndExtra = sizeof(WORD);
    // wnd_class.hIcon = NULL;
    // wnd_class.lpszClassName = szChildClass;
    // wnd_class.hIconSm = NULL;
    // RegisterClassEx(&wnd_class); 
// Window descriptor
// name, 0, 0, 
// X - long from left side of monitor to window, 
// Y - long from up side of monitor to window
// Size of window
    HWND hWnd = CreateWindow(szWndClassName, szTitle, WS_OVERLAPPEDWINDOW, 200, 100, 600, 400, 0, 0, hInstance, 0);

    ShowWindow(hWnd, SW_SHOWDEFAULT); // smtms iShow here 
   
   
    MSG msg;
    int status;
// queue messages
// main handle
// all message for window applicacion 
    while ((status = GetMessage(&msg, 0, 0, 0)))
    { 
                
        // printf("Get message = 0x%x\n", msg.message);      
        // printf("status -> 0x%d\n", status);
        if (msg.message == WM_QUIT) break;
        
        DispatchMessage(&msg); // or WndProc with args
    }
    
    // printf("exit code : %d\n ", msg.wParam); // returning code in wParam
// In PostQuitMessage 
    return msg.wParam; 
}
 
