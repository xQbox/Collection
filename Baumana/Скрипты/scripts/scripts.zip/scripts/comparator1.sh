#Скрипт реализующий компаратор для сравнения последовательностей действительных чисел располагающихся в двух текстовых файлах
#!/bin/bash

# проверка количества аргументов
if [ $# -lt 2 ]; then
    exit 1
fi

vb=false

if [ "$3" == "-v" ] || [ "$3" == "--verbose" ]; then
    vb=true
fi

f1=$1
f2=$2

# маска для данной задачи
mask="[+-]?[0-9]+.?[0-9]*"

# записываем результат grep в соответсвующие переменные
text1=$(grep -Eo "$mask" "$f1")
text2=$(grep -Eo "$mask" "$f2")

# echo $text1
# echo $text2

# сравниваем их
if [ "$text1" != "$text2" ]; then
    if $vb; then
        echo Not equal files!
    fi
    exit 1
fi

if $vb; then
    echo Equal files!
fi

exit 0