#!/usr/bin/env bash
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CLEAR='\033[0m'

n_pos=$(find ./func_tests/data/ -name "pos_??_args.txt" | wc -l) # Количество позитивных тестов
n_neg=$(find ./func_tests/data/ -name "neg_??_args.txt" | wc -l) # Количество негативных тестов

vb=false
if [ "$1" == "-v" ] || [ "$1" == "--verbose" ]; then
    vb=true # проверка корректности указания ключа 
elif [ -n "$1" ]; then
    echo Invalid argument \""$1"\"!$'\n'Valid arguments are -v, --verbose
    exit 1
fi

errors_pos=0
errors_neg=0

i=1
while [ $i -le "$n_pos" ]; do # Перебираем все положительные тесты  
    if [ $i -lt 10 ]; then
    	if $vb; then
    		echo Positive Test_$i
    	fi
        ./func_tests/scripts/pos_case_Result.sh "./func_tests/data/pos_0""$i""_in.txt" "./func_tests/data/pos_0""$i""_out.txt" "./func_tests/data/pos_0""$i""_args.txt"

        rc=$?
        if [ $rc = 1 ]; then
            if $vb; then
                echo -e "${RED}FAILED${CLEAR}"
                echo Ожидаемый результат:
                cat "./func_tests/data/pos_0""$i""_out.txt"
                echo
                echo Фактический результат:
                cat test_output_pos.txt 
                echo
            fi
            errors_pos=$((errors_pos+1)) # если произошла ошибка, увеличиваем счетчик
        elif $vb; then
        	echo -e "${GREEN}PASSED${CLEAR}"
        fi

    else
    	if $vb; then
    		echo Positive Test_$i
    	fi
        ./func_tests/scripts/pos_case_Result.sh "./func_tests/data/pos_""$i""_in.txt" "./func_tests/data/pos_""$i""_out.txt" "./func_tests/data/pos_""$i""_args.txt"
        rc=$?
        if [ $rc = 1 ]; then
            if $vb; then
                echo -e "${RED}FAILED${CLEAR}"
                echo Ожидаемый результат: 
                cat "./func_tests/data/pos_""$i""_out.txt"
                echo Фактический результат:
                cat test_output_pos.txt 
                echo $'\n'
            fi
            errors_pos=$((errors_pos+1))
        elif $vb; then
        	echo -e "${GREEN}PASSED${CLEAR}"
        fi
    fi
    i=$((i+1))
done

if [ $errors_pos == 0 ] && $vb; then
    echo $'\n'All positive tests succeeded$'\n'
elif $vb; then
	echo
fi

i=1
while [ $i -le "$n_neg" ]; do # проходим по всем негативным тестам
    if [ $i -lt 10 ]; then
    	if $vb; then
    		echo Negative Test_$i
    	fi
        ./func_tests/scripts/neg_case.sh "./func_tests/data/neg_0""$i""_in.txt" "./func_tests/data/neg_0""$i""_out.txt" "./func_tests/data/neg_0""$i""_args.txt"
        rc=$?
        if [ $rc = 1 ]; then
            if $vb; then
                echo -e "${RED}FAILED${CLEAR}"
            fi
            # errors_neg+=1
            errors_neg=$((errors_neg+1)) # произошла ошибка - увеличиваем счетчик 
        elif $vb; then
        	echo -e "${GREEN}PASSED${CLEAR}"
        fi
    else
    	if $vb; then
    		echo Negative Test_$i
    	fi
        ./func_tests/scripts/neg_case.sh "./func_tests/data/neg_""$i""_in.txt" "./func_tests/data/neg_""$i""_out.txt" "./func_tests/data/neg_""$i""_args.txt"
        rc=$?
        if [ $rc = 1 ]; then
            if $vb; then
                echo -e "${RED}FAILED${CLEAR}"
            fi
            errors_neg=$((errors_neg+1))
        elif $vb; then
        	echo -e "${GREEN}PASSED${CLEAR}"
        fi
    fi
    i=$((i+1))
done

if [ $errors_neg == 0 ] && $vb; then
    echo $'\n'All negative tests succeeded$'\n'$'\n'
fi

if [ $((errors_neg + errors_pos)) != 0 ] && $vb; then
	echo Result: $((errors_neg + errors_pos)) errors found
elif $vb; then
	echo Testing successful, 0 issues found
fi

exit $((errors_pos+errors_neg)) # возвращаем количество ошибок
