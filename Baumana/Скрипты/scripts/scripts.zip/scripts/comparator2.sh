#Скрипт реализующий компаратор для сравнения последовательностей действительных чисел располагающихся в двух текстовых файлах
#!/bin/bash

# проверка количества аргументов
if [ $# -lt 2 ]; then
    exit 1
fi

vb=false
if [ "$3" == "-v" ] || [ "$3" == "--verbose" ]; then
    vb=true
fi

f1=$1
f2=$2

# маска для данной задачи
mask="Result: [+-]?[0-9]+.?[0-9]*"

# записываем результат grep в соответсвующие переменные
searchstring="Result: "

text1=`cat $f1`
text2=`cat $f2`

value1=${text1#*$searchstring}
value2=${text2#*$searchstring}
idx1=$(( ${#text1} - ${#value1} - ${#searchstring} ))
idx2=$(( ${#text2} - ${#value2} - ${#searchstring} ))

if [ $idx1 -lt 0 -o $idx2 -lt 0 ]; then
    [ $idx1 -lt 0 ] && echo "'string:' подстрока не была найдена в файле $f1"
    [ $idx2 -lt 0 ] && echo "'string:' подстрока не была найдена в файле $f2"
    exit 0
elif [ "$value1" == "$value2" ]; then
    echo "Подстроки в двух файлах равны"
else
    echo "Подстроки в двух файлах не равны"
fi

if $vb; then
    echo "Подстрока в файле $f1: $value1"
    echo "Подстрока в файле $f2: $value2"
fi

exit 0