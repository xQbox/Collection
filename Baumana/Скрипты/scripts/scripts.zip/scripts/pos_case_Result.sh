#!/usr/bin/env bash

in=$1
out=$2
args=$(cat $3)

if [ "$args" = "st" ] || [ "$args" = "dt" ]; then
    ./app.exe $args $in > test_output_pos.txt 2>&1 # Проверка кода возврата, запись
else 
    ./app.exe $args > test_output_pos.txt 2>&1 # Проверка кода возврата, запись
fi

# результата в вспомогательный файл

if [ $? = 1 ]; then
    exit 1
fi

./func_tests/scripts/comparator.sh test_output_pos.txt "$out" # Запуск соответствующего компаратора

if [ $? = 1 ]; then
    exit 1
fi

exit 0
