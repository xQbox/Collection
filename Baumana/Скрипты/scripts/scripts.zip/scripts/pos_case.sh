#!/usr/bin/env bash

cat "$1" | ../../app.exe > test_output_pos.txt 2>&1 # Проверка кода возврата, запись
# результата в вспомогательный файл

if [ $? = 1 ] || [ ! -s test_output_pos.txt ]; then
    exit 1
fi

./comparator.sh test_output_pos.txt "$2" # Запуск соответствующего компаратора
if [ $? = 1 ]; then
    exit 1
fi
