#!/usr/bin/env bash

in=$1
out=$2
args=$(cat $3)

if [ "$args" = "st" ] || [ "$args" = "dt" ]; then
    ./app.exe $args $in > test_output_neg.txt 2>&1 # Помещаем выдачу программы в вспомогательный файл, чтобы избежать распечаток на экран
else 
    ./app.exe $args > test_output_neg.txt 2>&1 # Проверка кода возврата, запись
fi
rc=$?

if [ $rc = 0 ]; then  # Проверка кода возврата и наличия выдачи после работы программы
    exit 1
fi
